<?php 
echo "Mệt vãi lồn";
?>