<h2>Danh sách tài khoản</h2>
<table class="table table-stripped">
    <thead>
        <th>category_id</th>
        <th>category_name</th>
        <th>icon</th>
        <th>
            <a href="<?= ADMIN_URL . 'account/add-form' ?>" class="btn btn-sm btn-success">Tạo mới</a>
        </th>
    </thead>
    <tbody>
        <?php foreach ($dsuser as $u) : ?>
            <tr>
                <td><?= $u['category_id'] ?></td>
                <td><?= $u['category_name'] ?></td>
                <td><?= $u['icon'] ?></td>
                <td>
                    <img src="<?= PUBLIC_ASSETS . 'upload/avatars/' . $u['image'] ?>" width="100">
                </td>
                <td>
                    <a href="<?= ADMIN_URL . 'account/edit-form?id=' . $u['user_id'] ?>" class="btn btn-sm btn-info">Sửa</a>
                    <a href="javascript:;" data-url="<?= ADMIN_URL . 'account/delete?id=' . $u['user_id'] ?>" data-name="<?= $u['name'] ?>" class="btn btn-sm btn-danger btn_remove_account">Xóa</a>
                </td>
            </tr>
        <?php endforeach ?>
    </tbody>
</table>