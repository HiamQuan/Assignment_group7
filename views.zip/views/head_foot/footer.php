<footer>
    <section class="footer">
        <aside class="box-footer wow zoomIn">
            <img class="mb-4" src="<?=IMAGE_URL?>footer/grandrestaurant_logo.png" alt="">
        </aside>
        <aside class="box-footer wow zoomIn col-xs-sm-3">
            <h3>LOCATION</h3>
            <ul class="ul">
                <li><i class="fas fa-map-marker-alt mr-1"></i> CS1:Số 147 Phùng Hưng,Đồng Xuân,Hoàn Kiếm,Hà Nội</li>
                <li><i class="fas fa-map-marker-alt mr-1"></i> CS2:Số 125 Quán Thánh,Tham Quan,Ba Đình,Hà Nội</li>
                <li class="pt-2 pb-2"><i class="fas fa-phone fa-flip-horizontal mr-1"></i> 0372.0113.08</li>
                <li><i class="fas fa-envelope mr-1"></i> dinhlcph18273@fpt.edu.vn</li>
            </ul>
        </aside>
        <aside class="box-footer wow zoomIn col-xs-sm-3">
            <h3>REVERSATION</h3>
            <ul class="ul">
                <li><a href="">0326.669.823 <i class="angle right icon"></i></a></li>
                <li><a href="">Make a reversation <i class="angle right icon"></i></a></li>
            </ul>
        </aside>

        <aside class="box-footer wow zoomIn col-xs-sm-3">
            <h3>OPENING HOURS</h3>
            <ul class="ul">
                <li><a href="">Mon-Fri:8:30am - 10:30pm <i class="angle right icon"></i></a></li>
                <li><a href="">Sat-Sun 10am - 9:30pm <i class="angle right icon"></i></a></li>
            </ul>
        </aside>

    </section>
</footer>