<!-- jQuery -->
<script src="<?= ADMIN_ASSETS ?>plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?= ADMIN_ASSETS ?>plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?= ADMIN_ASSETS ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?= ADMIN_ASSETS ?>plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="<?= ADMIN_ASSETS ?>plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="<?= ADMIN_ASSETS ?>plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="<?= ADMIN_ASSETS ?>plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?= ADMIN_ASSETS ?>plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="<?= ADMIN_ASSETS ?>plugins/moment/moment.min.js"></script>
<script src="<?= ADMIN_ASSETS ?>plugins/daterangepicker/daterangepicker.js"></script>
<script src="<?= ADMIN_ASSETS ?>plugins/sweetalert2/sweetalert2.min.js"></script>

<!-- Tempusdominus Bootstrap 4 -->
<script src="<?= ADMIN_ASSETS ?>plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="<?= ADMIN_ASSETS ?>plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?= ADMIN_ASSETS ?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= ADMIN_ASSETS ?>dist/js/adminlte.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<!-- AdminLTE for demo purposes -->
<!-- <script src="<?= ADMIN_ASSETS ?>dist/js/demo.js"></script> -->
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!-- <script src="<?= ADMIN_ASSETS ?>dist/js/pages/dashboard.js"></script> -->